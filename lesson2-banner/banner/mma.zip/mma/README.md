# transcript
* UFC - Ultimate Fighting Championship tickets are selling out fast ️
* Don't miss out - complete your purchase now and secure yours before they're snapped up!
